<?php 
    header('location: php/home_page.php');
?>